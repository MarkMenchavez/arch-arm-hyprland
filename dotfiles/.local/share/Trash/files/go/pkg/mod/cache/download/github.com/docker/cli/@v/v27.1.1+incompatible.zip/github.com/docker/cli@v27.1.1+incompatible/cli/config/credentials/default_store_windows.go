package credentials

func defaultCredentialsStore() string {
	return "wincred"
}
