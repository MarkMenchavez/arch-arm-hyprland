# Kill

Go package for killing processes across different platforms. Handles killing children of processes as well as the process itself.
