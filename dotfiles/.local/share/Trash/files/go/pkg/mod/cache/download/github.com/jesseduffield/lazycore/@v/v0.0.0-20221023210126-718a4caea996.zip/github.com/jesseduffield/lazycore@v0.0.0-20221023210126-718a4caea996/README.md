# lazycore
Shared functionality for lazygit, lazydocker, etc
